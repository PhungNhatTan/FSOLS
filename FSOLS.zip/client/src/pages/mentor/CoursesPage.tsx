import CoursePage from "../../components/manage/course/CoursePage";

export default function CoursesPage() {
  return <CoursePage />;
}
