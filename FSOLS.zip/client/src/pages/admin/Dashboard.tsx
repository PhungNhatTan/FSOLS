export default function Dashboard() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      <p>Welcome! Select an option from the sidebar.</p>
    </div>
  )
}
