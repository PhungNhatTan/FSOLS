import create from './create.js';
import get from './get.js';
import getByCourse from './getByCourse.js';
import getByLesson from './getByLesson.js';
// import getAll from './getAll.js';
// import update from './update.js';
// import remove from './delete.js';

export default {
  create,
  get,
  getByCourse,
  getByLesson,
//   getAll,
//   update,
//   remove,
};
