import getNav from "./getSpecializationCourseNav.js";

export default{
    getNav,
};
