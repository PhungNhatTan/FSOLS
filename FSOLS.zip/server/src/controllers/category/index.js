import getAll from './getAll.js';

export default {
  getAll,
};
