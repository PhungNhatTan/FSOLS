import submitExam from "./submitExam.js";
import getDetailedExamResult from "./getDetailedExamResult.js";

export default{
    submitExam,
    getDetailedExamResult,
}
