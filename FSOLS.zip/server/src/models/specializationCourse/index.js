import getSpecializationCourseNav from "./getSpecializationCourseNav.js";

export default{
    getSpecializationCourseNav,
}
