import get from "./get.js";
import create from "./create.js";

export default {
    get,
    create,
}
