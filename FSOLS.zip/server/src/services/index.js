import createQuestionBankEntry from "./questionBank/createQuestionBankHelper.js";

export default {
    createQuestionBankEntry,
}
